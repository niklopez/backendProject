package com.cst438.domain;

public record AccountCredentials(String username, String password) {
	
}
