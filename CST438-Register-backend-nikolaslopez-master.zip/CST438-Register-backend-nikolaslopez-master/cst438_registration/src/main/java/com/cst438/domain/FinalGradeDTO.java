package com.cst438.domain;

public record FinalGradeDTO (String studentEmail, String studentName, String grade, int courseId) {

}